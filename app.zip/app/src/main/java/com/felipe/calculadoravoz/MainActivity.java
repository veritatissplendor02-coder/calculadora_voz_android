package com.felipe.calculadoravoz;

import android.Manifest;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.content.SharedPreferences;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.media.AudioManager;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.speech.RecognitionListener;
import android.speech.RecognizerIntent;
import android.speech.SpeechRecognizer;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

import org.json.JSONArray;

import java.text.Normalizer;
import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Deque;
import java.util.Locale;

public class MainActivity extends Activity {

    private static final int REQ_AUDIO = 1001;
    private static final String PREFS_NAME = "calculadora_por_voz_v22";
    private static final String HISTORY_KEY = "calculation_history";

    private final CalculationEngine engine = new CalculationEngine();
    private final Deque<String> history = new ArrayDeque<>();
    private final Handler handler = new Handler(Looper.getMainLooper());

    private SpeechRecognizer speechRecognizer;
    private Intent speechIntent;
    private TextView statusView;
    private TextView heardView;
    private TextView resultView;
    private TextView historyView;
    private TextView historyTitle;
    private Button viewHistoryButton;
    private ScrollView mainScroll;
    private Button micButton;

    // Comportamento da versão 1.8: depois de tocar em FALAR uma vez,
    // o aplicativo volta a ouvir automaticamente após cada conta.
    private boolean continuousMode = false;
    private boolean speechInProgress = false;
    private boolean pendingPermissionStart = false;

    // Alguns serviços de reconhecimento de voz do Android/Samsung emitem
    // bipes de início/fim. O app silencia temporariamente apenas os canais
    // em que esses bipes costumam tocar e restaura os volumes ao parar.
    private AudioManager audioManager;
    private int previousSystemVolume = -1;
    private int previousMusicVolume = -1;
    private boolean recognizerAudioSilenced = false;

    private final Runnable restartListeningRunnable = this::startListeningInternal;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        audioManager = (AudioManager) getSystemService(Context.AUDIO_SERVICE);
        buildUi();
        restoreHistory();
        configureSpeech();
    }

    private void buildUi() {
        int bg = getColor(R.color.app_background);
        int textPrimary = getColor(R.color.text_primary);
        int textSecondary = getColor(R.color.text_secondary);

        ScrollView scroll = new ScrollView(this);
        // A tela toda pode ser rolada com o dedo, inclusive durante a escuta.
        // Mantemos a barra visível para indicar que há conteúdo abaixo.
        scroll.setFillViewport(true);
        scroll.setVerticalScrollBarEnabled(true);
        scroll.setScrollbarFadingEnabled(false);
        scroll.setSmoothScrollingEnabled(true);
        scroll.setBackgroundColor(bg);
        scroll.setSoundEffectsEnabled(false);
        mainScroll = scroll;

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(20), dp(22), dp(20), dp(30));
        root.setSoundEffectsEnabled(false);
        scroll.addView(root, new ScrollView.LayoutParams(
                ScrollView.LayoutParams.MATCH_PARENT,
                ScrollView.LayoutParams.WRAP_CONTENT));

        TextView title = new TextView(this);
        title.setText("Calculadora por Voz");
        title.setTextColor(textPrimary);
        title.setTextSize(29);
        title.setTypeface(null, android.graphics.Typeface.BOLD);
        root.addView(title);

        TextView subtitle = new TextView(this);
        subtitle.setText("Toque uma vez em FALAR. Ela continua ouvindo e mantém sua última conta na tela.");
        subtitle.setTextColor(textSecondary);
        subtitle.setTextSize(16);
        subtitle.setPadding(0, dp(6), 0, dp(16));
        root.addView(subtitle);

        statusView = new TextView(this);
        statusView.setText("Pronto. Toque em FALAR para ligar a escuta contínua.");
        statusView.setTextColor(getColor(R.color.success));
        statusView.setTextSize(15);
        statusView.setPadding(0, 0, 0, dp(12));
        root.addView(statusView);

        LinearLayout card = new LinearLayout(this);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setBackgroundResource(R.drawable.card_background);
        card.setPadding(dp(20), dp(20), dp(20), dp(20));
        LinearLayout.LayoutParams cardLp = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT);
        cardLp.bottomMargin = dp(18);
        root.addView(card, cardLp);

        TextView heardLabel = new TextView(this);
        heardLabel.setText("EU OUVI");
        heardLabel.setTextColor(textSecondary);
        heardLabel.setTextSize(12);
        heardLabel.setTypeface(null, android.graphics.Typeface.BOLD);
        card.addView(heardLabel);

        heardView = new TextView(this);
        heardView.setText("—");
        heardView.setTextColor(textPrimary);
        heardView.setTextSize(20);
        heardView.setPadding(0, dp(6), 0, dp(22));
        card.addView(heardView);

        TextView resultLabel = new TextView(this);
        resultLabel.setText("RESULTADO");
        resultLabel.setTextColor(textSecondary);
        resultLabel.setTextSize(12);
        resultLabel.setTypeface(null, android.graphics.Typeface.BOLD);
        card.addView(resultLabel);

        resultView = new TextView(this);
        resultView.setText("0");
        resultView.setTextColor(textPrimary);
        resultView.setTextSize(52);
        resultView.setMaxLines(1);
        resultView.setAutoSizeTextTypeUniformWithConfiguration(28, 56, 2, TypedValue.COMPLEX_UNIT_SP);
        resultView.setGravity(Gravity.END);
        resultView.setTypeface(null, android.graphics.Typeface.BOLD);
        resultView.setPadding(0, dp(8), 0, 0);
        card.addView(resultView);

        micButton = new Button(this);
        micButton.setText("🎤  FALAR");
        micButton.setTextSize(20);
        micButton.setTextColor(Color.WHITE);
        micButton.setAllCaps(false);
        micButton.setGravity(Gravity.CENTER);
        micButton.setBackgroundResource(R.drawable.button_primary);
        micButton.setMinHeight(dp(72));
        micButton.setSoundEffectsEnabled(false); // remove o som de clique do botão
        LinearLayout.LayoutParams micLp = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, dp(74));
        micLp.bottomMargin = dp(12);
        root.addView(micButton, micLp);
        micButton.setOnClickListener(v -> toggleContinuousListening());

        Button clearButton = new Button(this);
        clearButton.setText("Apagar conta atual / nova conta");
        clearButton.setTextSize(17);
        clearButton.setTextColor(textPrimary);
        clearButton.setAllCaps(false);
        clearButton.setBackgroundResource(R.drawable.button_secondary);
        clearButton.setMinHeight(dp(58));
        clearButton.setSoundEffectsEnabled(false); // remove o som de clique do botão
        root.addView(clearButton, new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, dp(60)));
        clearButton.setOnClickListener(v -> clearEverything(
                continuousMode ? "Conta atual apagada. O histórico foi mantido. Continuo ouvindo."
                        : "Conta atual apagada. O histórico foi mantido."));

        // Atalho para alcançar o histórico mesmo em celulares com tela pequena.
        viewHistoryButton = new Button(this);
        viewHistoryButton.setText("↓  VER HISTÓRICO (0)");
        viewHistoryButton.setTextSize(17);
        viewHistoryButton.setAllCaps(false);
        viewHistoryButton.setTextColor(textPrimary);
        viewHistoryButton.setBackgroundResource(R.drawable.button_secondary);
        viewHistoryButton.setSoundEffectsEnabled(false);
        LinearLayout.LayoutParams jumpLp = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, dp(60));
        jumpLp.topMargin = dp(12);
        root.addView(viewHistoryButton, jumpLp);
        viewHistoryButton.setOnClickListener(v -> mainScroll.post(() ->
                mainScroll.smoothScrollTo(0, Math.max(0, historyTitle.getTop() - dp(12)))));

        TextView historyHint = new TextView(this);
        historyHint.setText("Deslize a tela para cima ou toque em VER HISTÓRICO para conferir todas as contas.");
        historyHint.setTextSize(14);
        historyHint.setTextColor(textSecondary);
        historyHint.setPadding(0, dp(8), 0, dp(2));
        root.addView(historyHint);

        historyTitle = new TextView(this);
        historyTitle.setText("Histórico de cálculos (0)");
        historyTitle.setTextColor(textPrimary);
        historyTitle.setTextSize(19);
        historyTitle.setTypeface(null, android.graphics.Typeface.BOLD);
        historyTitle.setPadding(0, dp(22), 0, dp(8));
        root.addView(historyTitle);

        historyView = new TextView(this);
        historyView.setText("Nenhuma conta ainda.");
        historyView.setTextColor(textSecondary);
        historyView.setTextSize(16);
        historyView.setLineSpacing(dp(5), 1.18f);
        // Nenhuma altura máxima nem limite de 8 contas: a própria tela rola.
        root.addView(historyView);

        Button backToTopButton = new Button(this);
        backToTopButton.setText("↑  VOLTAR AO INÍCIO");
        backToTopButton.setTextSize(16);
        backToTopButton.setTextColor(textPrimary);
        backToTopButton.setAllCaps(false);
        backToTopButton.setBackgroundResource(R.drawable.button_secondary);
        backToTopButton.setSoundEffectsEnabled(false);
        LinearLayout.LayoutParams backLp = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, dp(58));
        backLp.topMargin = dp(16);
        root.addView(backToTopButton, backLp);
        backToTopButton.setOnClickListener(v -> mainScroll.post(() -> mainScroll.smoothScrollTo(0, 0)));

        Button clearHistoryButton = new Button(this);
        clearHistoryButton.setText("APAGAR HISTÓRICO");
        clearHistoryButton.setTextSize(15);
        clearHistoryButton.setTextColor(textSecondary);
        clearHistoryButton.setAllCaps(false);
        clearHistoryButton.setBackgroundResource(R.drawable.button_secondary);
        clearHistoryButton.setSoundEffectsEnabled(false);
        LinearLayout.LayoutParams clearHistoryLp = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, dp(54));
        clearHistoryLp.topMargin = dp(10);
        root.addView(clearHistoryButton, clearHistoryLp);
        clearHistoryButton.setOnClickListener(v -> confirmClearHistory());

        TextView examplesTitle = new TextView(this);
        examplesTitle.setText("Você pode falar:");
        examplesTitle.setTextColor(textPrimary);
        examplesTitle.setTextSize(17);
        examplesTitle.setTypeface(null, android.graphics.Typeface.BOLD);
        examplesTitle.setPadding(0, dp(24), 0, dp(8));
        root.addView(examplesTitle);

        TextView examples = new TextView(this);
        examples.setText("• “125 mais 37”\n" +
                "• “duzentos dividido por cinco”\n" +
                "• “15 por cento de 240”\n" +
                "• “raiz quadrada de 144”\n" +
                "• “mais 20” ou “menos 20” (continua do resultado anterior)\n" +
                "• “apagar”, “limpar” ou “zerar”\n" +
                "• “parar” (desliga a escuta contínua)");
        examples.setTextColor(textSecondary);
        examples.setTextSize(16);
        examples.setLineSpacing(0, 1.18f);
        root.addView(examples);

        setContentView(scroll);
    }

    private void configureSpeech() {
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            statusView.setText("O reconhecimento de voz não está disponível neste aparelho.");
            statusView.setTextColor(getColor(R.color.danger));
            micButton.setEnabled(false);
            return;
        }

        speechRecognizer = SpeechRecognizer.createSpeechRecognizer(this);
        speechRecognizer.setRecognitionListener(new RecognitionListener() {
            @Override
            public void onReadyForSpeech(Bundle params) {
                speechInProgress = true;
                showListeningStatus("🎤 Escuta contínua ligada — pode falar.");
            }

            @Override
            public void onBeginningOfSpeech() {
                showListeningStatus("Estou ouvindo…");
            }

            @Override public void onRmsChanged(float rmsdB) { }
            @Override public void onBufferReceived(byte[] buffer) { }

            @Override
            public void onEndOfSpeech() {
                if (continuousMode) {
                    statusView.setText("Processando… depois continuo ouvindo.");
                    statusView.setTextColor(getColor(R.color.text_secondary));
                }
            }

            @Override
            public void onError(int error) {
                speechInProgress = false;
                if (!continuousMode) return;

                if (error == SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS) {
                    stopContinuousListening("A permissão do microfone é necessária.");
                    showError("O aplicativo precisa da permissão do microfone.");
                    return;
                }

                // NO_MATCH e SPEECH_TIMEOUT são normais em escuta contínua:
                // simplesmente reiniciamos sem transformar isso em erro para o usuário.
                if (error == SpeechRecognizer.ERROR_NO_MATCH ||
                        error == SpeechRecognizer.ERROR_SPEECH_TIMEOUT) {
                    statusView.setText("Continuo ouvindo…");
                    statusView.setTextColor(getColor(R.color.primary));
                    scheduleRestart(300);
                    return;
                }

                if (error == SpeechRecognizer.ERROR_RECOGNIZER_BUSY) {
                    statusView.setText("Ajustando o microfone…");
                    statusView.setTextColor(getColor(R.color.text_secondary));
                    scheduleRestart(700);
                    return;
                }

                statusView.setText(friendlySpeechError(error) + " Vou tentar novamente.");
                statusView.setTextColor(getColor(R.color.danger));
                scheduleRestart(1200);
            }

            @Override
            public void onResults(Bundle results) {
                speechInProgress = false;
                ArrayList<String> matches = results.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION);
                if (matches != null && !matches.isEmpty()) {
                    handleRecognitionResults(matches);
                    if (continuousMode) scheduleRestart(350);
                    return;
                }

                if (continuousMode) {
                    statusView.setText("Não entendi. Continuo ouvindo…");
                    statusView.setTextColor(getColor(R.color.text_secondary));
                    scheduleRestart(350);
                }
            }

            @Override
            public void onPartialResults(Bundle partialResults) {
                // Não substituímos "EU OUVI" por transcrições provisórias.
                // A última conta deve continuar visível enquanto ouvimos a próxima.
            }

            @Override public void onEvent(int eventType, Bundle params) { }
        });

        speechIntent = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
        speechIntent.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
        speechIntent.putExtra(RecognizerIntent.EXTRA_LANGUAGE, "pt-BR");
        speechIntent.putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true);
        speechIntent.putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 5);
        speechIntent.putExtra(RecognizerIntent.EXTRA_PREFER_OFFLINE, false);
        speechIntent.putExtra(RecognizerIntent.EXTRA_PROMPT, "Fale a conta");
    }

    private void toggleContinuousListening() {
        if (continuousMode) {
            stopContinuousListening("Escuta contínua desligada.");
        } else {
            startContinuousListening();
        }
    }

    private void startContinuousListening() {
        if (speechRecognizer == null) return;

        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            pendingPermissionStart = true;
            requestPermissions(new String[]{Manifest.permission.RECORD_AUDIO}, REQ_AUDIO);
            return;
        }

        pendingPermissionStart = false;
        continuousMode = true;
        updateMicButton();
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        statusView.setText("Ligando a escuta contínua…");
        statusView.setTextColor(getColor(R.color.primary));

        // Mantém os canais dos bipes silenciados enquanto a escuta contínua
        // estiver ligada. Eles são restaurados assim que a escuta é parada.
        silenceRecognizerAudio();
        startListeningInternal();
    }

    private void startListeningInternal() {
        handler.removeCallbacks(restartListeningRunnable);
        if (!continuousMode || speechRecognizer == null || speechInProgress) return;

        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            stopContinuousListening("Escuta contínua desligada.");
            showError("O aplicativo perdeu a permissão do microfone.");
            return;
        }

        // Reaplica o silêncio antes de cada novo ciclo. Se o serviço do Android
        // tentar tocar o bipe de início/fim em SYSTEM ou MUSIC, o volume está zero.
        silenceRecognizerAudio();

        speechInProgress = true;
        // O reinício automático da escuta não apaga a conta já calculada.
        showListeningStatus("🎤 Ouvindo…");
        try {
            speechRecognizer.startListening(speechIntent);
        } catch (Exception e) {
            speechInProgress = false;
            statusView.setText("Não consegui iniciar o microfone. Vou tentar novamente.");
            statusView.setTextColor(getColor(R.color.danger));
            scheduleRestart(900);
        }
    }

    private void stopContinuousListening(String message) {
        continuousMode = false;
        pendingPermissionStart = false;
        handler.removeCallbacks(restartListeningRunnable);

        if (speechRecognizer != null) {
            try {
                speechRecognizer.cancel();
            } catch (Exception ignored) { }
        }

        speechInProgress = false;
        getWindow().clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        restoreRecognizerAudio();
        updateMicButton();
        statusView.setText(message);
        statusView.setTextColor(getColor(R.color.success));
    }

    private void scheduleRestart(long delayMs) {
        handler.removeCallbacks(restartListeningRunnable);
        if (!continuousMode) return;
        handler.postDelayed(restartListeningRunnable, delayMs);
    }

    private void handleRecognitionResults(ArrayList<String> matches) {
        // O Android fornece até 5 hipóteses. Tentamos a mais bem ranqueada primeiro;
        // se ela não formar uma conta válida, passamos para a próxima.
        String firstError = null;

        for (int i = 0; i < matches.size(); i++) {
            String spoken = matches.get(i);
            if (spoken == null || spoken.trim().isEmpty()) continue;

            // Comandos de controle só são aceitos na hipótese principal para
            // evitar que uma alternativa secundária desligue a escuta por engano.
            if (i == 0 && isStopListeningCommand(spoken)) {
                handleSpokenResult(spoken, null, true);
                return;
            }

            CalculationEngine.Result r = engine.process(spoken);
            if (r.success) {
                handleSpokenResult(spoken, r, false);
                return;
            }
            if (firstError == null) firstError = r.error;
        }

        // Uma fala não reconhecida não apaga a última conta válida.
        showError(firstError == null ? "Não entendi a conta. Tente falar de outro jeito." : firstError);
    }

    private void handleSpokenResult(String spoken, CalculationEngine.Result r, boolean stopCommand) {
        String cleanedSpoken = CalculationEngine.cleanRecognizedTextForDisplay(spoken);
        if (cleanedSpoken.isEmpty()) cleanedSpoken = spoken;

        if (stopCommand) {
            stopContinuousListening("Escuta contínua desligada pelo comando “parar”.");
            return;
        }

        if (r == null) {
            showError("Não entendi a conta. Tente falar de outro jeito.");
            return;
        }

        if (r.clear) {
            clearEverything(continuousMode ?
                    "Conta atual apagada. O histórico foi mantido. Continuo ouvindo." :
                    "Conta atual apagada. O histórico foi mantido.");
            return;
        }

        // Atualiza a última conta SOMENTE quando houver um novo cálculo válido.
        // A transcrição permanece visível acima do resultado até a próxima conta
        // ou até o usuário pedir para apagar.
        heardView.setText(cleanedSpoken);
        resultView.setText(r.display);
        statusView.setText(continuousMode ? "Conta calculada. Continuo ouvindo…" : "Conta calculada.");
        statusView.setTextColor(getColor(R.color.success));
        addHistory(cleanedSpoken + "  =  " + r.display);
    }

    private boolean isStopListeningCommand(String spoken) {
        if (spoken == null) return false;
        String n = Normalizer.normalize(spoken, Normalizer.Form.NFD)
                .replaceAll("\\p{M}+", "")
                .toLowerCase(Locale.ROOT)
                .trim()
                .replaceAll("\\s+", " ");

        return n.equals("parar") ||
                n.equals("pare") ||
                n.equals("parar de ouvir") ||
                n.equals("pare de ouvir") ||
                n.equals("desligar microfone") ||
                n.equals("desligar o microfone") ||
                n.equals("parar escuta") ||
                n.equals("parar a escuta");
    }

    private void addHistory(String line) {
        history.addFirst(line);
        // Guardamos todas as operações, inclusive quando o app for fechado.
        saveHistory();
        updateHistoryUi();
    }

    private void updateHistoryUi() {
        int total = history.size();
        historyTitle.setText("Histórico de cálculos (" + total + ")");
        viewHistoryButton.setText("↓  VER HISTÓRICO (" + total + ")");
        if (total == 0) {
            historyView.setText("Nenhuma conta ainda.");
            return;
        }

        StringBuilder sb = new StringBuilder();
        int i = 1;
        for (String item : history) {
            if (sb.length() > 0) sb.append("\n\n");
            sb.append(i++).append(". ").append(item);
        }
        historyView.setText(sb.toString());
    }

    private void saveHistory() {
        JSONArray saved = new JSONArray();
        for (String item : history) saved.put(item);
        getSharedPreferences(PREFS_NAME, MODE_PRIVATE)
                .edit().putString(HISTORY_KEY, saved.toString()).apply();
    }

    private void restoreHistory() {
        SharedPreferences prefs = getSharedPreferences(PREFS_NAME, MODE_PRIVATE);
        String saved = prefs.getString(HISTORY_KEY, "[]");
        try {
            JSONArray lines = new JSONArray(saved);
            for (int i = 0; i < lines.length(); i++) {
                String line = lines.optString(i, "");
                if (!line.isEmpty()) history.addLast(line);
            }
        } catch (Exception ignored) {
            // Se o arquivo salvo tiver algum erro, a calculadora continua utilizável.
        }
        updateHistoryUi();
    }

    private void confirmClearHistory() {
        new AlertDialog.Builder(this)
                .setTitle("Apagar todo o histórico?")
                .setMessage("Isso apagará permanentemente as contas já registradas neste aparelho. A conta atual continuará visível.")
                .setNegativeButton("Cancelar", null)
                .setPositiveButton("Apagar histórico", (dialog, which) -> {
                    history.clear();
                    saveHistory();
                    updateHistoryUi();
                    statusView.setText("Histórico apagado.");
                    statusView.setTextColor(getColor(R.color.success));
                })
                .show();
    }

    private void clearEverything(String message) {
        engine.clear();
        // Limpar a conta atual NÃO apaga as operações antigas.
        heardView.setText("—");
        resultView.setText("0");
        statusView.setText(message);
        statusView.setTextColor(getColor(R.color.success));
    }

    private void showError(String message) {
        statusView.setText(message);
        statusView.setTextColor(getColor(R.color.danger));
    }

    private void showListeningStatus(String message) {
        updateMicButton();
        statusView.setText(message);
        statusView.setTextColor(getColor(R.color.primary));
    }

    private void updateMicButton() {
        if (micButton == null) return;
        micButton.setText(continuousMode ? "⏹  PARAR ESCUTA" : "🎤  FALAR");
    }

    private String friendlySpeechError(int error) {
        switch (error) {
            case SpeechRecognizer.ERROR_NO_MATCH:
                return "Não entendi a fala.";
            case SpeechRecognizer.ERROR_SPEECH_TIMEOUT:
                return "Não ouvi nada.";
            case SpeechRecognizer.ERROR_NETWORK:
            case SpeechRecognizer.ERROR_NETWORK_TIMEOUT:
                return "Problema de internet no reconhecimento de voz.";
            case SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS:
                return "O aplicativo precisa da permissão do microfone.";
            case SpeechRecognizer.ERROR_RECOGNIZER_BUSY:
                return "O microfone está ocupado.";
            case SpeechRecognizer.ERROR_CLIENT:
                return "O reconhecimento de voz foi interrompido.";
            default:
                return "Não consegui reconhecer a fala.";
        }
    }

    /**
     * Silencia os canais usados pelos bipes do SpeechRecognizer.
     * Os valores anteriores são guardados e restaurados ao parar a escuta.
     */
    private void silenceRecognizerAudio() {
        if (audioManager == null || recognizerAudioSilenced) return;

        boolean changed = false;
        try {
            previousSystemVolume = audioManager.getStreamVolume(AudioManager.STREAM_SYSTEM);
            audioManager.setStreamVolume(
                    AudioManager.STREAM_SYSTEM,
                    0,
                    AudioManager.FLAG_REMOVE_SOUND_AND_VIBRATE);
            changed = true;
        } catch (Exception ignored) {
            previousSystemVolume = -1;
        }

        try {
            previousMusicVolume = audioManager.getStreamVolume(AudioManager.STREAM_MUSIC);
            audioManager.setStreamVolume(
                    AudioManager.STREAM_MUSIC,
                    0,
                    AudioManager.FLAG_REMOVE_SOUND_AND_VIBRATE);
            changed = true;
        } catch (Exception ignored) {
            previousMusicVolume = -1;
        }

        recognizerAudioSilenced = changed;
    }

    private void restoreRecognizerAudio() {
        if (audioManager == null || !recognizerAudioSilenced) return;

        try {
            if (previousSystemVolume >= 0) {
                audioManager.setStreamVolume(
                        AudioManager.STREAM_SYSTEM,
                        previousSystemVolume,
                        AudioManager.FLAG_REMOVE_SOUND_AND_VIBRATE);
            }
        } catch (Exception ignored) { }

        try {
            if (previousMusicVolume >= 0) {
                audioManager.setStreamVolume(
                        AudioManager.STREAM_MUSIC,
                        previousMusicVolume,
                        AudioManager.FLAG_REMOVE_SOUND_AND_VIBRATE);
            }
        } catch (Exception ignored) { }

        previousSystemVolume = -1;
        previousMusicVolume = -1;
        recognizerAudioSilenced = false;
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == REQ_AUDIO) {
            if (grantResults.length > 0 &&
                    grantResults[0] == PackageManager.PERMISSION_GRANTED &&
                    pendingPermissionStart) {
                pendingPermissionStart = false;
                startContinuousListening();
            } else {
                pendingPermissionStart = false;
                restoreRecognizerAudio();
                showError("Sem permissão do microfone, a calculadora não consegue ouvir sua voz.");
            }
        }
    }

    @Override
    protected void onStop() {
        if (continuousMode) {
            stopContinuousListening("Escuta pausada porque o aplicativo saiu da tela.");
        } else {
            restoreRecognizerAudio();
        }
        super.onStop();
    }

    @Override
    protected void onDestroy() {
        handler.removeCallbacksAndMessages(null);
        restoreRecognizerAudio();

        if (speechRecognizer != null) {
            try {
                speechRecognizer.cancel();
            } catch (Exception ignored) { }
            speechRecognizer.destroy();
            speechRecognizer = null;
        }
        super.onDestroy();
    }

    private int dp(int value) {
        return Math.round(value * getResources().getDisplayMetrics().density);
    }
}
