package com.felipe.calculadoravoz;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.text.Normalizer;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public final class CalculationEngine {

    public static final class Result {
        public final boolean success;
        public final boolean clear;
        public final String display;
        public final String error;

        private Result(boolean success, boolean clear, String display, String error) {
            this.success = success;
            this.clear = clear;
            this.display = display;
            this.error = error;
        }

        public static Result value(String display) {
            return new Result(true, false, display, null);
        }

        public static Result cleared() {
            return new Result(true, true, "0", null);
        }

        public static Result error(String message) {
            return new Result(false, false, null, message);
        }
    }

    private Double lastResult;

    public void clear() {
        lastResult = null;
    }

    public Double getLastResult() {
        return lastResult;
    }

    public Result process(String spokenText) {
        if (spokenText == null || spokenText.trim().isEmpty()) {
            return Result.error("Não ouvi nenhuma conta.");
        }

        String n = normalize(spokenText);
        if (isClearCommand(n)) {
            clear();
            return Result.cleared();
        }

        // Remove formas naturais de começar uma pergunta, sem exigir frase rígida.
        n = n.replaceFirst("^(?:quanto\\s+e|qual\\s+e|calcule|calcular)\\s+", "").trim();
        n = n.replaceFirst("^(?:a|o)\\s+(?=raiz\\s+quadrada\\b)", "").trim();

        try {
            double value = evaluateNormalized(n);
            if (Double.isNaN(value) || Double.isInfinite(value)) {
                return Result.error("Esse cálculo não produz um número válido.");
            }
            lastResult = value;
            return Result.value(format(value));
        } catch (ArithmeticException e) {
            return Result.error(e.getMessage() == null ? "Não consegui fazer essa conta." : e.getMessage());
        } catch (IllegalArgumentException e) {
            return Result.error(e.getMessage() == null ? "Não entendi a conta. Tente falar de outro jeito." : e.getMessage());
        }
    }

    private double evaluateNormalized(String n) {
        // Exemplos: "15 por cento de 240" / "15% de 240"
        Matcher percentOf = Pattern.compile("^(.+?)\\s+(?:por\\s+cento|porcento|%)\\s+(?:de|do|da)\\s+(.+)$").matcher(n);
        if (percentOf.matches()) {
            double p = parseNumberPhrase(percentOf.group(1));
            double base = parseNumberPhrase(percentOf.group(2));
            return base * p / 100.0;
        }

        Matcher percentOnly = Pattern.compile("^(.+?)\\s+(?:por\\s+cento|porcento|%)$").matcher(n);
        if (percentOnly.matches()) {
            return parseNumberPhrase(percentOnly.group(1)) / 100.0;
        }

        Matcher sqrt = Pattern.compile("^(?:raiz\\s+quadrada\\s+(?:de|do|da)\\s+)(.+)$").matcher(n);
        if (sqrt.matches()) {
            double x = parseNumberPhrase(sqrt.group(1));
            if (x < 0) throw new ArithmeticException("Não existe raiz quadrada real de número negativo.");
            return Math.sqrt(x);
        }

        Matcher squared = Pattern.compile("^(.+?)\\s+ao\\s+quadrado$").matcher(n);
        if (squared.matches()) {
            double base = parseNumberPhrase(squared.group(1));
            return base * base;
        }

        Matcher cubed = Pattern.compile("^(.+?)\\s+ao\\s+cubo$").matcher(n);
        if (cubed.matches()) {
            double base = parseNumberPhrase(cubed.group(1));
            return base * base * base;
        }

        Matcher power = Pattern.compile("^(.+?)\\s+elevad[oa]\\s+(?:a|ao)\\s+(.+)$").matcher(n);
        if (power.matches()) {
            double base = parseNumberPhrase(power.group(1));
            double exp = parseNumberPhrase(power.group(2));
            return Math.pow(base, exp);
        }

        String expression = n;
        expression = expression.replaceAll("\\bquanto\\s+e\\b", " ");
        expression = expression.replaceAll("\\bcalcule\\b|\\bcalcular\\b|\\bfaca\\b|\\bfazer\\b", " ");
        expression = expression.replaceAll("\\bmultiplicad[oa]\\s+por\\b", " * ");
        expression = expression.replaceAll("\\bvezes\\b", " * ");
        expression = expression.replaceAll("\\bx\\b", " * ");
        expression = expression.replaceAll("\\bdividid[oa]\\s+por\\b", " / ");
        expression = expression.replaceAll("\\bdividido\\s+em\\b", " / ");
        expression = expression.replaceAll("\\bmais\\b", " + ");
        expression = expression.replaceAll("\\bmenos\\b", " - ");
        expression = expression.replaceAll("\\s+", " ").trim();

        if (expression.isEmpty()) {
            throw new IllegalArgumentException("Não entendi a conta.");
        }

        if (startsWithBinaryOperator(expression)) {
            if (lastResult == null) {
                throw new IllegalArgumentException("Faça uma conta primeiro para continuar pelo resultado anterior.");
            }
            expression = formatForParsing(lastResult) + " " + expression;
        }

        return evaluateExpression(expression);
    }

    private static boolean startsWithBinaryOperator(String expression) {
        String t = expression.trim();
        return t.startsWith("+") || t.startsWith("-") || t.startsWith("*") || t.startsWith("/");
    }

    private static double evaluateExpression(String expression) {
        List<Double> numbers = new ArrayList<>();
        List<Character> ops = new ArrayList<>();

        int start = 0;
        for (int i = 0; i < expression.length(); i++) {
            char c = expression.charAt(i);
            if (c == '+' || c == '*' || c == '/' || c == '-') {
                String before = expression.substring(start, i).trim();
                boolean unaryMinus = c == '-' && before.isEmpty() && (numbers.isEmpty() || (!ops.isEmpty() && start == i));
                if (unaryMinus) {
                    continue;
                }
                if (before.isEmpty()) {
                    throw new IllegalArgumentException("A conta ficou incompleta.");
                }
                numbers.add(parseNumberPhrase(before));
                ops.add(c);
                start = i + 1;
            }
        }
        String tail = expression.substring(start).trim();
        if (tail.isEmpty()) {
            throw new IllegalArgumentException("A conta ficou incompleta.");
        }
        numbers.add(parseNumberPhrase(tail));

        if (ops.isEmpty()) {
            return numbers.get(0);
        }
        if (numbers.size() != ops.size() + 1) {
            throw new IllegalArgumentException("Não entendi a ordem da conta.");
        }

        // Primeiro multiplicação e divisão.
        List<Double> reducedNumbers = new ArrayList<>();
        List<Character> reducedOps = new ArrayList<>();
        double current = numbers.get(0);
        for (int i = 0; i < ops.size(); i++) {
            char op = ops.get(i);
            double next = numbers.get(i + 1);
            if (op == '*') {
                current *= next;
            } else if (op == '/') {
                if (Math.abs(next) < 1e-15) throw new ArithmeticException("Não é possível dividir por zero.");
                current /= next;
            } else {
                reducedNumbers.add(current);
                reducedOps.add(op);
                current = next;
            }
        }
        reducedNumbers.add(current);

        // Depois soma e subtração.
        double result = reducedNumbers.get(0);
        for (int i = 0; i < reducedOps.size(); i++) {
            char op = reducedOps.get(i);
            double next = reducedNumbers.get(i + 1);
            if (op == '+') result += next;
            else if (op == '-') result -= next;
        }
        return result;
    }

    private static final Map<String, Integer> SMALL = new HashMap<>();
    private static final Map<String, Long> SCALE = new HashMap<>();

    static {
        SMALL.put("zero", 0);
        SMALL.put("um", 1); SMALL.put("uma", 1);
        SMALL.put("dois", 2); SMALL.put("duas", 2);
        SMALL.put("tres", 3); SMALL.put("quatro", 4); SMALL.put("cinco", 5);
        SMALL.put("seis", 6); SMALL.put("sete", 7); SMALL.put("oito", 8); SMALL.put("nove", 9);
        SMALL.put("dez", 10); SMALL.put("onze", 11); SMALL.put("doze", 12); SMALL.put("treze", 13);
        SMALL.put("quatorze", 14); SMALL.put("catorze", 14); SMALL.put("quinze", 15);
        SMALL.put("dezesseis", 16); SMALL.put("dezasseis", 16);
        SMALL.put("dezessete", 17); SMALL.put("dezassete", 17);
        SMALL.put("dezoito", 18); SMALL.put("dezenove", 19); SMALL.put("dezanove", 19);
        SMALL.put("vinte", 20); SMALL.put("trinta", 30); SMALL.put("quarenta", 40);
        SMALL.put("cinquenta", 50); SMALL.put("sessenta", 60); SMALL.put("setenta", 70);
        SMALL.put("oitenta", 80); SMALL.put("noventa", 90);
        SMALL.put("cem", 100); SMALL.put("cento", 100); SMALL.put("duzentos", 200);
        SMALL.put("duzentas", 200); SMALL.put("trezentos", 300); SMALL.put("trezentas", 300);
        SMALL.put("quatrocentos", 400); SMALL.put("quatrocentas", 400);
        SMALL.put("quinhentos", 500); SMALL.put("quinhentas", 500);
        SMALL.put("seiscentos", 600); SMALL.put("seiscentas", 600);
        SMALL.put("setecentos", 700); SMALL.put("setecentas", 700);
        SMALL.put("oitocentos", 800); SMALL.put("oitocentas", 800);
        SMALL.put("novecentos", 900); SMALL.put("novecentas", 900);

        SCALE.put("mil", 1_000L);
        SCALE.put("milhao", 1_000_000L); SCALE.put("milhoes", 1_000_000L);
        SCALE.put("bilhao", 1_000_000_000L); SCALE.put("bilhoes", 1_000_000_000L);
    }

    private static double parseNumberPhrase(String phrase) {
        String p = stripCurrencyWords(phrase).trim();
        if (p.isEmpty()) throw new IllegalArgumentException("Faltou um número na conta.");

        // Formas numéricas já reconhecidas como algarismos.
        // O reconhecimento pt-BR pode devolver "4.200" para quatro mil e duzentos.
        // Nesse caso o ponto é separador de milhar, não separador decimal.
        String compact = p.replace(" ", "");
        if (compact.matches("[-+]?\\d[\\d.,]*")) {
            return parseNumericLiteral(compact);
        }

        boolean negative = false;
        if (p.startsWith("negativo ")) {
            negative = true;
            p = p.substring("negativo ".length()).trim();
        } else if (p.startsWith("- ")) {
            negative = true;
            p = p.substring(2).trim();
        } else if (p.startsWith("+ ")) {
            p = p.substring(2).trim();
        }

        String[] decimalParts = p.split("\\b(?:virgula|ponto)\\b", 2);
        long integer = parseIntegerWords(decimalParts[0].trim());
        double value = integer;

        if (decimalParts.length == 2) {
            String fracText = decimalParts[1].trim();
            if (fracText.isEmpty()) throw new IllegalArgumentException("Faltou o valor depois da vírgula.");

            String digits;
            String compactFrac = fracText.replace(" ", "");
            if (compactFrac.matches("\\d+")) {
                digits = compactFrac;
            } else {
                StringBuilder sb = new StringBuilder();
                boolean everyTokenIsDigitWord = true;
                for (String token : fracText.split("\\s+")) {
                    if (token.equals("e")) continue;
                    Integer v = SMALL.get(token);
                    if (v != null && v >= 0 && v <= 9) sb.append(v);
                    else { everyTokenIsDigitWord = false; break; }
                }
                if (everyTokenIsDigitWord && sb.length() > 0) {
                    digits = sb.toString();
                } else {
                    long fracAsNumber = parseIntegerWords(fracText);
                    digits = Long.toString(Math.abs(fracAsNumber));
                }
            }
            value += Double.parseDouble("0." + digits);
        }

        return negative ? -value : value;
    }

    private static long parseIntegerWords(String words) {
        String p = words.trim();
        if (p.isEmpty()) return 0;

        String compact = p.replace(" ", "");
        if (compact.matches("\\d+")) return Long.parseLong(compact);

        long total = 0;
        long current = 0;
        boolean found = false;

        for (String token : p.split("\\s+")) {
            if (token.isEmpty() || token.equals("e") || token.equals("de") || token.equals("do") || token.equals("da")) {
                continue;
            }

            Integer small = SMALL.get(token);
            if (small != null) {
                current += small;
                found = true;
                continue;
            }

            Long scale = SCALE.get(token);
            if (scale != null) {
                found = true;
                if (scale == 1_000L) {
                    if (current == 0) current = 1;
                    total += current * scale;
                    current = 0;
                } else {
                    long chunk = current == 0 ? 1 : current;
                    total += chunk * scale;
                    current = 0;
                }
                continue;
            }

            throw new IllegalArgumentException("Não entendi o número \"" + token + "\".");
        }

        if (!found) throw new IllegalArgumentException("Não entendi esse número.");
        return total + current;
    }

    /**
     * Converte um literal numérico reconhecido por voz para double.
     * Regras principais para pt-BR:
     * - 4200 -> 4200
     * - 4.200 -> 4200 (ponto de milhar)
     * - 4.200,50 -> 4200.50
     * - 4,2 -> 4.2
     * - 0.125 -> 0.125 (mantém decimal quando a parte inteira é zero)
     */
    private static double parseNumericLiteral(String literal) {
        String s = literal.trim();
        if (s.isEmpty()) throw new IllegalArgumentException("Faltou um número na conta.");

        boolean negative = false;
        if (s.startsWith("-") || s.startsWith("+")) {
            negative = s.charAt(0) == '-';
            s = s.substring(1);
        }
        if (s.isEmpty() || !s.matches("\\d[\\d.,]*")) {
            throw new IllegalArgumentException("Não entendi esse número.");
        }

        int commas = countChar(s, ',');
        int dots = countChar(s, '.');
        String normalized;

        if (commas > 0 && dots > 0) {
            // Aceita tanto o padrão brasileiro 1.234,56 quanto uma eventual
            // transcrição 1,234.56. O último separador é tratado como decimal.
            int lastComma = s.lastIndexOf(',');
            int lastDot = s.lastIndexOf('.');
            char decimalSep = lastComma > lastDot ? ',' : '.';
            char groupingSep = decimalSep == ',' ? '.' : ',';

            if (countChar(s, decimalSep) != 1) {
                throw new IllegalArgumentException("Não entendi esse número.");
            }

            String[] parts = s.split(Pattern.quote(String.valueOf(decimalSep)), -1);
            if (parts.length != 2 || parts[0].isEmpty() || parts[1].isEmpty()) {
                throw new IllegalArgumentException("Não entendi esse número.");
            }
            if (!isValidGroupedInteger(parts[0], groupingSep) || !parts[1].matches("\\d+")) {
                throw new IllegalArgumentException("Não entendi esse número.");
            }

            String integerDigits = parts[0].replace(String.valueOf(groupingSep), "");
            normalized = integerDigits + "." + parts[1];
        } else if (commas > 0) {
            if (commas == 1) {
                String[] parts = s.split(",", -1);
                if (parts.length != 2 || parts[0].isEmpty() || parts[1].isEmpty() ||
                        !parts[0].matches("\\d+") || !parts[1].matches("\\d+")) {
                    throw new IllegalArgumentException("Não entendi esse número.");
                }
                // Em pt-BR, vírgula é separador decimal.
                normalized = parts[0] + "." + parts[1];
            } else if (isValidGroupedInteger(s, ',')) {
                // Raro, mas tolera transcrição com vírgulas de milhar: 1,234,567.
                normalized = s.replace(",", "");
            } else {
                throw new IllegalArgumentException("Não entendi esse número.");
            }
        } else if (dots > 0) {
            if (isValidBrazilianThousands(s)) {
                normalized = s.replace(".", "");
            } else if (dots == 1) {
                String[] parts = s.split("\\.", -1);
                if (parts.length != 2 || parts[0].isEmpty() || parts[1].isEmpty() ||
                        !parts[0].matches("\\d+") || !parts[1].matches("\\d+")) {
                    throw new IllegalArgumentException("Não entendi esse número.");
                }
                normalized = parts[0] + "." + parts[1];
            } else {
                throw new IllegalArgumentException("Não entendi esse número.");
            }
        } else {
            normalized = s;
        }

        double value = Double.parseDouble(normalized);
        return negative ? -value : value;
    }

    private static boolean isValidBrazilianThousands(String s) {
        // "4.200", "12.345" e "1.234.567" são tratados como milhares.
        // "0.125" fica decimal para não transformar 0,125 em 125.
        if (!s.matches("\\d{1,3}(?:\\.\\d{3})+")) return false;
        int firstDot = s.indexOf('.');
        String firstGroup = firstDot < 0 ? s : s.substring(0, firstDot);
        return !firstGroup.equals("0");
    }

    private static boolean isValidGroupedInteger(String s, char groupingSep) {
        if (s.indexOf(groupingSep) < 0) return s.matches("\\d+");
        String regex = "\\d{1,3}(?:" + Pattern.quote(String.valueOf(groupingSep)) + "\\d{3})+";
        return s.matches(regex);
    }

    private static int countChar(String s, char c) {
        int count = 0;
        for (int i = 0; i < s.length(); i++) if (s.charAt(i) == c) count++;
        return count;
    }

    private static String stripCurrencyWords(String text) {
        if (text == null) return "";
        String s = text;
        s = s.replaceAll("(?i)r\\s*\\$", " ");
        s = s.replaceAll("(?i)\\bbrl\\b", " ");
        s = s.replaceAll("(?i)\\b(?:real|reais)\\b", " ");
        return s.replaceAll("\\s+", " ").trim();
    }

    /**
     * Limpa apenas artefatos de moeda para o texto exibido em "EU OUVI".
     * Mantém a frase original o máximo possível.
     */
    public static String cleanRecognizedTextForDisplay(String text) {
        return stripCurrencyWords(text == null ? "" : text);
    }

    private static boolean isClearCommand(String n) {
        return n.matches("^(apagar|apague|limpar|limpe|zerar|zera|zerar tudo|apagar tudo|limpar tudo)$");
    }

    private static String normalize(String input) {
        String s = input.toLowerCase(Locale.forLanguageTag("pt-BR"));
        s = Normalizer.normalize(s, Normalizer.Form.NFD).replaceAll("\\p{M}+", "");
        s = s.replace('−', '-').replace('×', 'x').replace('÷', '/');

        // Alguns serviços de reconhecimento da Samsung/Google devolvem um número
        // falado como se fosse moeda, por exemplo: "R$ 4.200 dividido por 210".
        // A calculadora não é uma calculadora monetária, então o marcador de moeda
        // é descartado antes da interpretação da conta.
        s = stripCurrencyWords(s);

        // Não converta vírgula em ponto aqui. A distinção entre decimal e milhar
        // é feita em parseNumericLiteral, respeitando a escrita brasileira.
        s = s.replaceAll("[?!;:]", " ");
        s = s.replaceAll("[.]$", "");
        s = s.replaceAll("\\s+", " ").trim();
        return s;
    }

    public static String format(double value) {
        if (Math.abs(value) < 1e-12) value = 0;
        BigDecimal bd = BigDecimal.valueOf(value).setScale(10, RoundingMode.HALF_UP).stripTrailingZeros();
        return bd.toPlainString().replace('.', ',');
    }

    private static String formatForParsing(double value) {
        BigDecimal bd = BigDecimal.valueOf(value).stripTrailingZeros();
        return bd.toPlainString();
    }
}
